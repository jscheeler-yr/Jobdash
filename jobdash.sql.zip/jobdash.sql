-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 17, 2011 at 10:04 PM
-- Server version: 5.1.53
-- PHP Version: 5.3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `jobdash`
--

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE IF NOT EXISTS `departments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`) VALUES
(1, 'Account'),
(2, 'Creative'),
(3, 'Project Management'),
(4, 'Studio'),
(5, 'Other');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE IF NOT EXISTS `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `taken_by_id` int(11) NOT NULL,
  `projectID` int(11) NOT NULL,
  `taskID` int(11) NOT NULL,
  `object_name` text COLLATE latin1_general_ci NOT NULL,
  `created` datetime NOT NULL,
  `object_rel_manager` varchar(50) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `logs`
--


-- --------------------------------------------------------

--
-- Table structure for table `milestones`
--

CREATE TABLE IF NOT EXISTS `milestones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `milestone_typeID` int(11) NOT NULL,
  `milestone` date NOT NULL,
  `milestone_other` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `projectID` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `milestones`
--

INSERT INTO `milestones` (`id`, `milestone_typeID`, `milestone`, `milestone_other`, `projectID`) VALUES
(3, 7, '2011-03-21', '', 1),
(4, 1, '2011-03-16', '', 1),
(5, 1, '2011-03-17', '', 2),
(6, 2, '2011-03-19', '', 2),
(7, 3, '2011-03-21', '', 2);

-- --------------------------------------------------------

--
-- Table structure for table `milestone_types`
--

CREATE TABLE IF NOT EXISTS `milestone_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `milestone_types`
--

INSERT INTO `milestone_types` (`id`, `name`) VALUES
(1, 'Internal Review'),
(2, 'Client Review'),
(3, 'Revisions'),
(4, 'Assets to Studio'),
(5, 'Assets to Production'),
(6, 'Assets to Vendor'),
(7, 'Other');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE IF NOT EXISTS `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `typeID` int(11) NOT NULL,
  `type_other` varchar(25) COLLATE latin1_general_ci DEFAULT NULL,
  `jobNumber` varchar(14) COLLATE latin1_general_ci NOT NULL,
  `owner_userID` int(11) NOT NULL,
  `milestone` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `name`, `typeID`, `type_other`, `jobNumber`, `owner_userID`, `milestone`) VALUES
(1, 'Colgate-MCM Corporate Community events for African American and Hispanic communities', 9, NULL, 'YR9-ADM-987654', 1, '2011-03-16'),
(2, 'Project 2', 4, NULL, 'YR9-ADM-987654', 1, '2011-03-17');

-- --------------------------------------------------------

--
-- Table structure for table `project_types`
--

CREATE TABLE IF NOT EXISTS `project_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `project_types`
--

INSERT INTO `project_types` (`id`, `name`) VALUES
(1, 'Print'),
(2, 'TV'),
(3, 'Radio'),
(4, 'Online'),
(5, 'Online - Email'),
(6, 'Online - Banner'),
(7, 'Online - Website'),
(8, 'Online - Other'),
(9, 'Campaign Concepting'),
(10, 'Other'),
(11, 'Other - New Biz Pitch'),
(12, 'Other - Duratrans');

-- --------------------------------------------------------

--
-- Table structure for table `region`
--

CREATE TABLE IF NOT EXISTS `region` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `region`
--

INSERT INTO `region` (`id`, `name`) VALUES
(1, 'Chicago'),
(2, 'Miami'),
(3, 'New York'),
(4, 'San Francisco');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE IF NOT EXISTS `tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `userID` int(11) NOT NULL,
  `statusID` int(11) NOT NULL,
  `lastUpdateOn` datetime NOT NULL,
  `lastUpdateBy` int(11) NOT NULL,
  `projectID` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `name`, `userID`, `statusID`, `lastUpdateOn`, `lastUpdateBy`, `projectID`) VALUES
(1, 'Task 1', 1, 1, '2011-03-17 10:02:58', 1, 1),
(2, 'Task 2', 1, 1, '2011-03-17 10:02:58', 1, 1),
(4, 'Task 4', 4, 1, '2011-03-17 10:02:58', 1, 1),
(5, 'Task 1', 1, 1, '0000-00-00 00:00:00', 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `task_comments`
--

CREATE TABLE IF NOT EXISTS `task_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` text COLLATE latin1_general_ci NOT NULL,
  `lastUpdateOn` datetime NOT NULL,
  `lastUpdateBy` int(11) NOT NULL,
  `taskID` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `task_comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `task_status`
--

CREATE TABLE IF NOT EXISTS `task_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(10) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `task_status`
--

INSERT INTO `task_status` (`id`, `name`) VALUES
(1, 'assigned'),
(2, 'working'),
(3, 'complete'),
(4, 'on-hold'),
(5, 'waiting');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `lastname` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `departmentID` int(11) NOT NULL,
  `titleID` int(11) NOT NULL,
  `phone` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(75) COLLATE latin1_general_ci NOT NULL,
  `salt` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `regionID` int(11) NOT NULL,
  `permissionsID` int(11) NOT NULL,
  `lastLoggedIn` datetime DEFAULT NULL,
  `picture` varchar(50) COLLATE latin1_general_ci DEFAULT 'default.jpg',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `departmentID`, `titleID`, `phone`, `email`, `password`, `salt`, `regionID`, `permissionsID`, `lastLoggedIn`, `picture`) VALUES
(1, 'Jessica', 'Scheeler', 4, 7, '305-347-1959', 'jessica.scheeler@yr.com', 'cd147e60be415eee41acef77113eeb10', '60b535c5', 2, 1, '2011-03-08 16:16:10', 'JessicaScheeler.jpg'),
(4, 'Michelle', 'Muzea', 3, 11, '305-347-0000', 'michelle.muzea@yr.com', '34e70c11f52376cdadf4cd79cef95476', 'xQVSwQEO@', 2, 1, NULL, 'default.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user_permissions`
--

CREATE TABLE IF NOT EXISTS `user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `description` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='Defines permission levels ' AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user_permissions`
--

INSERT INTO `user_permissions` (`id`, `name`, `description`) VALUES
(1, 'Admin - Complete Access', 'Complete access to view and modify any project in any region. \r\nAccess to modify and view all users\r\nAccess to modify user titles, offices, project types, departments, user permissions, and milestone types'),
(2, 'Admin - Regional Access', 'View any project in any region. \r\nModify any project in own region\r\nAccess to modify and view users in own region as long as they are restricted users.'),
(3, 'User - Restricted Access', 'Can view all project across any region but cannot modify any project unless assigned to it. \r\nCan modify personal profile\r\nIf assigned to a task, user can: comment or change the status only\r\nUser cannot modify any project information');

-- --------------------------------------------------------

--
-- Table structure for table `user_titles`
--

CREATE TABLE IF NOT EXISTS `user_titles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `abbr` varchar(8) COLLATE latin1_general_ci NOT NULL,
  `full` varchar(35) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=16 ;

--
-- Dumping data for table `user_titles`
--

INSERT INTO `user_titles` (`id`, `abbr`, `full`) VALUES
(1, 'CD', 'Creative Director'),
(2, 'CW', 'Copywriter'),
(3, 'AD', 'Art Director'),
(4, 'DS', 'Designer'),
(5, 'ACD', 'Associate Creative Director'),
(6, 'SA', 'Studio Artist'),
(7, 'WEB DEV', 'Web Developer'),
(8, 'FLASH', 'Flash Developer'),
(9, 'CGI', 'Computer Graphics Imaging'),
(10, 'GD', 'Graphic Designer'),
(11, 'PM', 'Project Manager'),
(12, 'TM', 'Traffic Manager'),
(13, 'AE', 'Account Executive'),
(14, 'AAE', 'Assistant Account Executive'),
(15, 'VP', 'Vice President');
